<?php include('header.php'); ?>
<?php include('navbar_photos.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head.php'); ?>
					
					</div>
				
				<div class="pull-center">
					<?php include('slider.php'); ?>
				</div>
			
				<div class="span2">
				<h4></h4>
			
				</div>
				<div class="span10">
				
				
					
					
				
				
				</div>
			
			</div>
		</div>
    </div>
<?php include('footer.php') ?>