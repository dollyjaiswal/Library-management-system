<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_dashboard.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">	
			<div class="span12">		
                       
				<?php include('slider.php'); ?>
				
				
			</div>		
			</div>
		</div>
    </div>
<?php include('footer.php') ?>