  		<?php include('tooltip.php'); ?>	
		
    <div class="navbar navbar-fixed-top nav-wrapper">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="nav-collapse collapse">
					<ul class="nav">
					<li class=""><a  rel="tooltip"  data-placement="bottom" title="Home" id="home"   href="index.php"></i>&nbsp;Home</a> </li>
					
					<li class="active">
					<a rel="tooltip"  data-placement="bottom" title="About Us" id="login" href="about.php"></i>&nbsp;About Us</a> 
					</li>
					
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Photos" id="login" href="photos.php"></i>&nbsp;Gallery</a>
					</li>
				
					<li class="">
					<a rel="tooltip"  data-placement="bottom" title="Click Here to Login" id="login" href="librarian"></i>&nbsp;Login</a>
					</li>
					
					<li class="signup"><span class="sg"></span></li>
					</ul>

			

                   
                    </div>
                </div>
            </div>
        </div>
   
	
	
	     	